﻿using System;

namespace E_Commerce
{
    public class Class1
    {
    }
}
